# BatchOS
This is a OS, i guess. but its a batch file really

just open the os.bat to open it.